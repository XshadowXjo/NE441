package fr.esisar;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

public class Client {

	public static void main(String[] args) throws IOException {
		Client client = new Client();
        client.execute();                
    }

    private void execute() throws IOException
    {
        //
        System.out.println("Demarrage du client ...");

        //Creation de la socket
        Socket socket = new Socket();

        // Connexion au serveur 
        InetSocketAddress adrDest = new InetSocketAddress("127.0.0.1", 2000);
        socket.connect(adrDest);
        
        FileOutputStream fos = new FileOutputStream("/home/userir/file_client.txt");

        
        byte[] bufR = new byte[10000];
        InputStream is = socket.getInputStream();
        int lenBufR = is.read(bufR);
        if (lenBufR!=-1)
        {
        	fos.write(bufR,0,lenBufR);
        }
        fos.close();
        socket.close();
        System.out.println("Arret du client .");
    }

}
