package fr.esisar;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Serveur {

	public static void main(String[] args) throws IOException {
		Serveur serveur = new Serveur();
        serveur.execute();

    }



    private void execute() throws IOException
    {
        //
        System.out.println("Demarrage du serveur ...");


        ServerSocket socketEcoute = new ServerSocket();
        socketEcoute.bind(new InetSocketAddress(2000));


        // Attente de la connexion d'un client
        System.out.println("Attente de la connexion du client ...");
        Socket socketConnexion = socketEcoute.accept();
        
        
        
        FileInputStream fis = new FileInputStream("/home/userir/file_serveur.txt");
        byte[] buf = new byte[10000];
        //int len = fis.read(buf);
        fis.close();
        
        OutputStream os = socketConnexion.getOutputStream();
        os.write(buf);
        System.out.println("Message envoyé");
        
        socketConnexion.close();

        socketEcoute.close();
        System.out.println("Arret du serveur .");
    }
    

}
