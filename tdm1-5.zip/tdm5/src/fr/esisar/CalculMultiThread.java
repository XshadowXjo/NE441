package fr.esisar;

import java.util.ArrayList;
import java.util.List;

public class CalculMultiThread extends Thread{

	 private int start;
	 private int end;
	 private double result;
	 static int N=2000000000;
	 
	 
		
	public CalculMultiThread(int start, int end) {
		this.start = start;
		this.end = end;
	}
	
	public static void main(String[] args) throws InterruptedException {
		long start = System.currentTimeMillis();
		int nbr = 8;
		double result = 0;
		List<CalculMultiThread> threads = new ArrayList<>();
		for (int k=0; k<nbr; k++) {
			CalculMultiThread c = new CalculMultiThread((N/nbr)*k+1,(N/nbr)*(k+1));
			threads.add(c);
			c.start();
			}
		double finalResult = 0;
		for (CalculMultiThread thread : threads) {
            thread.join(); // Attend la fin de chaque thread
            finalResult += thread.result; // Récupère le résultat
        }

		System.out.println("Resultat: "+ finalResult);
		
		long stop = System.currentTimeMillis();
	System.out.println("Elapsed Time = "+(stop-start)+" ms");
	}

	public void run() {
		result = 0;
		for(long k=start; k<=end; k++) {
			result += 1d/(k*k);
		}
	}

}
