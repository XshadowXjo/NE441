package fr.esisar;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


public class SampleFileCopy {
	public static void main(String[] args) throws Exception
    {
	     long start = System.currentTimeMillis();
	     SampleFileCopy f = new SampleFileCopy();
	     f.execute();
		 long stop = System.currentTimeMillis();
		 System.out.println("Elapsed Time = "+(stop-start)+" ms");
    }
 
    
    public void execute() throws IOException {
        System.out.println("Début copie du fichier");
        FileInputStream fis = new FileInputStream("/home/userir/file1");
        FileOutputStream fos = new FileOutputStream("/home/userir/file2");
        byte[] buf = new byte[1000];

        int len = fis.read(buf);
        while(len!=-1)
        {
            fos.write(buf,0,len);
            len = fis.read(buf);
        }
        fis.close();
        fos.close();
        System.out.println("Fin copie du fichier");
    }

 
    
}
