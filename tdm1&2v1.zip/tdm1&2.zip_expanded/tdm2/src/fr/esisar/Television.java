package fr.esisar;

import java.awt.Color;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;

import javax.swing.JFrame;

public class Television {
	
	public static void main(String[] args) throws Exception
    {
		Television t = new Television();
		t.execute();
    }
	
	public void execute() throws InterruptedException, IOException {
		
		DatagramSocket socket = new DatagramSocket(null);
        socket.bind(new InetSocketAddress(7050));
        
        JFrame frame = new JFrame("Chenillard");
        frame.setSize(300,300);
        
        frame.getContentPane().setBackground(Color.GREEN);
        frame.setVisible(true);
        

        // Changement de couleur de la fenêtre
        for (int k=0; k<3; k++){
        	
        	byte[] bufR = new byte[2048];
            DatagramPacket dpR = new DatagramPacket(bufR, bufR.length);
            socket.receive(dpR);
            String message = new String(bufR, dpR.getOffset(), dpR.getLength());
            System.out.println("Message recu = "+message);

	        if(message.startsWith("red")) {
	            System.out.println("On passe au rouge ");
	        	frame.getContentPane().setBackground(Color.RED);     
	        }
	        else if(message.startsWith("green")){
	            System.out.println("On passe au vert ");
	            frame.getContentPane().setBackground(Color.GREEN);
	        }
	        else {
	            System.out.println("Veuillez entrer une couleur valide");

	        }
            System.out.println("Fin de boucle ");

	        frame.setVisible(true);
	        Thread.sleep(1000);
	     }
        frame.dispose();

        
        // Fermeture de la socket
        socket.close();
        System.out.println("Arret du serveur .");

        
    }
}



