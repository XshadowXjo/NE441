package fr.esisar;

public class PingPongUDP {

	public static void main(String[] args) {
		PingPongUDP test = new PingPongUDP();
		test.execute1();
		test.execute2();

		
	}
	
	public void execute1() {
		
	}
	public void execute2(){
		
	}

}
