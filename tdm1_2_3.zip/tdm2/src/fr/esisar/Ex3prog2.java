package fr.esisar;

import java.awt.Color;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;

import javax.swing.JFrame;

public class Ex3prog2 {

	public static void main(String[] args) throws IOException, InterruptedException {
		Ex3prog2 test = new Ex3prog2();
		test.execute();

	}
	
	public void execute() throws IOException, InterruptedException{
		DatagramSocket socket = new DatagramSocket(null);
		socket.bind(new InetSocketAddress(4002));
        InetSocketAddress adrDest = new InetSocketAddress("127.0.0.1", 4001);
        
        JFrame frame = new JFrame("Chenillard");
        frame.setSize(300,300);
        
        frame.getContentPane().setBackground(Color.GREEN);
        frame.setVisible(true);
        
        for (int k=0; k<5; k++) {

	        byte[] bufR = new byte[2048];
	        DatagramPacket dpR = new DatagramPacket(bufR, bufR.length);
	        socket.receive(dpR);
	        String reponse = new String(bufR, dpR.getOffset(), dpR.getLength());
	        System.out.println("Le serveur a répondu "+reponse); 
	        
	    	frame.getContentPane().setBackground(Color.RED);
	        frame.setVisible(true);
	        Thread.sleep(1000);
	        
	    	frame.getContentPane().setBackground(Color.GREEN);
	        frame.setVisible(true);
	        
	        byte[] bufE = new String("switch").getBytes();
	        DatagramPacket dpE = new DatagramPacket(bufE, bufE.length, adrDest);
	        socket.send(dpE);
	    	System.out.println("Envoi d'un paquet UDP avec switch");
	    	
        }
        frame.dispose();

     // Fermeture de la socket
        socket.close();
        System.out.println("Arret du serveur.");
	}

}
