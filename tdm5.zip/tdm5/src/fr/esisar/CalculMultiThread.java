package fr.esisar;

public class CalculMultiThread extends Thread{

	 private int start;
	 private int end;
	 private double result;
	 
	 
		
	public CalculMultiThread(int start, int end) {
		this.start = start;
		this.end = end;
	}
	
	public static void main(String[] args) throws InterruptedException {
		long start = System.currentTimeMillis();
		//int nbr = 4;
		//CalculMultiThread [] threads = new CalculMultiThread[nbr];
		//for (int k=0; k<nbr; k++) {
		//	CalculMultiThread c = new CalculMultiThread((N/nbr)*k+1,(N/nbr)*(k+1));
		//}
		CalculMultiThread c1 = new CalculMultiThread(1,500000000);
		CalculMultiThread c2 = new CalculMultiThread(500000000,1000000000);
		CalculMultiThread c3 = new CalculMultiThread(1000000000,1500000000);
		CalculMultiThread c4 = new CalculMultiThread(1500000000,2000000000);
		c1.start();
		c2.start();
		c3.start();
		c4.start();
		c1.join();
		c2.join();
		c3.join();
		c4.join();
		double result = c1.result+ c2.result + c3.result+ c4.result;
		System.out.println("Resultat: "+ result);
		
		long stop = System.currentTimeMillis();
	System.out.println("Elapsed Time = "+(stop-start)+" ms");
	}

	public void run() {
		result = 0;
		for(long k=start; k<=end; k++) {
			result += 1d/(k*k);
		}
	}

}
