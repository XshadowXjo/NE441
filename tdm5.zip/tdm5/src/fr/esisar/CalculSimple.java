package fr.esisar;

public class CalculSimple {

	 static int N = 2000000000;
	
	public static void main(String[] args) {
		CalculSimple c = new CalculSimple();
		c.execute();
	}

	public void execute() {
		long start = System.currentTimeMillis();
		
		double result = 0;
		for(long k=1; k<=N; k++) {
			result += 1d/(k*k);
		}
		System.out.println("Résultat :"+ result);
		
		long stop = System.currentTimeMillis();
		System.out.println("Elapsed Time = "+(stop-start)+" ms");
		
	}

}
